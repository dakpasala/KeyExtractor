package Part1;

import java.util.*;
public class Sector {

    private String name;
    private Map<Integer, Double> emissions;

    public Sector(String name, Map<Integer, Double> green) {
        this.name = name;
        this.emissions = green;
    }
    public String getName() {
        return this.name;
    }
    public Map<Integer, Double> getEmissions() {
        return this.emissions;
    }

//    public static Part2.Sector sectorWithBiggestChangeInEmissions(List<Part2.Sector> sectors, int startYear, int endYear) {
//        double max = 0;
//        double avg = 0;
//        String sectorname = " ";
//        Part2.Sector rs = null;
//        for (Part2.Sector sector: sectors) {
//            for (int i=startYear; i<=endYear; i++) {
//                avg += sector.getEmissions().get(i);
//            }
//            avg = avg / (endYear - startYear);
//            if (avg > max) {
//                max = avg;
//                sectorname = sector.getName();
//                rs = sector;
//            }
//        }
//        System.out.println("Name of Part1.Sector: " + sectorname);
//        System.out.println("Highest Average in Greenhouse gases: " + avg);
//        return rs;
//
//    }
}
