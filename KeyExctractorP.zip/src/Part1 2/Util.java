package Part1;

import java.util.*;
public class Util {

    public static int getYearWithHighestEmissions(Country c) {
        double max = 0;
        int year = 0;

        for (Map.Entry<Integer, Emission> emissions : c.getEmissions().entrySet()) {
                double t = emissions.getValue().getCO2() + emissions.getValue().getCH4() + emissions.getValue().getN2O();
                if (t > max) {
                    max = t;
                    year = emissions.getKey();
                }


        }
        return year;
    }

    public static int yearWithHighestEmissions(Sector s) {
        double max = 0;
        int year = 0;
        for(Map.Entry<Integer, Double> emissions: s.getEmissions().entrySet()) {
            if (emissions.getValue() > max) {
                max = emissions.getValue();
                year = emissions.getKey();
            }
        }
        return year;

}}

