package Part3;




import java.util.Map;
import java.util.*;

public class Country {

    private String name;
    private Map<Integer, Emission> emissions;

    public Country(String name, Map<Integer, Emission> green) {
        this.name = name;
        this.emissions = green;
    }
    public String getName() {
        return this.name;
    }
    public Map<Integer, Emission> getEmissions() {
        return this.emissions;
    }
    public static Country countryWithHighestCH4InYear(List<Country> countries, int year) {
        double max = 0;
        Country rs = null;
        for (int i =0; i<countries.size(); i++) {
            Country c = countries.get(i);
            for (Map.Entry<Integer, Emission> emission: c.getEmissions().entrySet()) {
                if (emission.getKey() == year) {
                    if (emission.getValue().getCH4() > max) {
                        max = emission.getValue().getCH4();
                        rs = countries.get(i);
                    }
                }
            }

        }
        return rs;
    }
    public static Country countryWithHighestChangeInEmissions(List<Country>countries, int startYear, int endYear) {
        double max = 0;
        String countryname = " ";
        Country rs = null;
        for (Country country : countries) {
            double start = country.getEmissions().get(startYear).getCH4() +
                    country.getEmissions().get(startYear).getCO2() + country.getEmissions().get(startYear).getN2O();
            double end = country.getEmissions().get(endYear).getCH4() +
                    country.getEmissions().get(endYear).getCO2() + country.getEmissions().get(endYear).getN2O();
            double difference = end - start;

            if (difference > max) {
                max = difference;
                countryname = country.getName();
                rs = country;
            }
        }

        System.out.println("Part1.Country Name: " + countryname);
        System.out.printf("The difference in Greenhouse gases from %d to %d: %.2f\n", startYear, endYear, max);
        return rs;
    }

}
