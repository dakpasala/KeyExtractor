package Part3;

import java.util.Map;
import java.util.*;

public class Sector {

    private String name;
    private Map<Integer, Double> emissions;

    public Sector(String name, Map<Integer, Double> green) {
        this.name = name;
        this.emissions = green;
    }
    public String getName() {
        return this.name;
    }
    public Map<Integer, Double> getEmissions() {
        return this.emissions;
    }

    public static Sector sectorWithBiggestChangeInEmissions(List<Sector> sectors, int startYear, int endYear) {
        Double max = -9999999999999999.0;
        String sectorname = "";
        Sector rs = null;
        for (Sector sector: sectors) {
            double avg = 0;
            int i = startYear;
            while (i <= endYear) {
                avg += sector.getEmissions().get(i);
                i++;
            }
            if ((avg /(endYear - startYear+1)) > max) {
                max = avg / (endYear - startYear+1);
                sectorname = sector.getName();
                rs = sector;
            }
        }
        System.out.println("Name of Sector: " + sectorname);
        System.out.println("Highest Average in Greenhouse gases: " + max);
        return rs;

    }
}
