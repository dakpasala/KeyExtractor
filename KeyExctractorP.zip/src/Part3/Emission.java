package Part3;

public class Emission {

    private double C02;
    private double N20;
    private double CH4;

    public Emission(double c, double n, double c1) {
        this.C02 = c;
        this.N20 = n;
        this.CH4 = c1;
    }

    public double getCO2() {
        return this.C02;
    }

    public double getN2O() {
        return this.N20;
    }

    public double getCH4() {
        return this.CH4;
    }




}
