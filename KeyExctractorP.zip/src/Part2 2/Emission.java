package Part2;

public class Emission {

    private double CO2;
    private double N2O;
    private double CH4;

    public Emission(double c, double n, double c1) {
        this.CO2 = c;
        this.N2O = n;
        this.CH4 = c1;
    }

    public double getCO2() {
        return this.CO2;
    }

    public double getN2O() {
        return this.N2O;
    }

    public double getCH4() {
        return this.CH4;
    }




}
