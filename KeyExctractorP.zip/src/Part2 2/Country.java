package Part2;

import java.util.Map;
public class Country {

    private String name;
    private Map<Integer, Emission> emissions;

    public Country(String name, Map<Integer, Emission> green) {
        this.name = name;
        this.emissions = green;
    }
    public String getName() {
        return this.name;
    }
    public Map<Integer, Emission> getEmissions() {
        return this.emissions;
    }
    public int getYearWithHighestEmissions() {
        double max = 0;
        int year = 0;

        for (Map.Entry<Integer, Emission> emissions : this.emissions.entrySet()) {
            double t = emissions.getValue().getCO2() + emissions.getValue().getCH4() + emissions.getValue().getN2O();
            if (t > max) {
                max = t;
                year = emissions.getKey();
            }


        }
        return year;
    }
}
