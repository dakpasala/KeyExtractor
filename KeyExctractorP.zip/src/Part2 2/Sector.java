package Part2;

import java.util.Map;
public class Sector {

    private String name;
    private Map<Integer, Double> emissions;

    public Sector(String name, Map<Integer, Double> green) {
        this.name = name;
        this.emissions = green;
    }
    public String getName() {
        return this.name;
    }
    public Map<Integer, Double> getEmissions() {
        return this.emissions;
    }
    public int getYearWithHighestEmissions() {
        double max = 0;
        int year = 0;
        for(Map.Entry<Integer, Double> emissions: this.emissions.entrySet()) {
            if (emissions.getValue() > max) {
                max = emissions.getValue();
                year = emissions.getKey();
            }
        }
        return year;

    }
}
